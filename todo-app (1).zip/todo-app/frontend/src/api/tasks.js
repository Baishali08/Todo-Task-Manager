const BASE_URL = process.env.REACT_APP_API_URL || '/api/tasks';

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

export const getTasks = (params = {}) => {
  const query = new URLSearchParams(params).toString();
  return request(query ? `?${query}` : '');
};

export const createTask = (body) =>
  request('', { method: 'POST', body: JSON.stringify(body) });

export const updateTask = (id, body) =>
  request(`/${id}`, { method: 'PATCH', body: JSON.stringify(body) });

export const toggleTask = (id) =>
  request(`/${id}/toggle`, { method: 'PATCH' });

export const deleteTask = (id) =>
  request(`/${id}`, { method: 'DELETE' });
